# ActivityLifecycle
Activity Lifecycle is a simple android application designed as part of a Udacity training course. The purpose of the application is to demonstrate how the lifecycle methods in the android framework function.
