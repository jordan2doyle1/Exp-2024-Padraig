package com.dnielfe.manager.fragments;

public final class BrowserFragment extends AbstractBrowserFragment {
    // Implements default behavior from AbstractBrowserFragment
}
