Please make sure these boxes are checked before submitting your pull request - thanks!

- [ ] Acknowledge that you're contributing your code under Apache v2.0 license

- [ ] Apply the `AndroidStyle.xml` style template to your code in Android Studio.