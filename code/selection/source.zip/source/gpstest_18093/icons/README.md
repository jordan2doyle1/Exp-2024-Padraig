Use inverse_satellite with web launcher icon generator:
https://romannurik.github.io/AndroidAssetStudio/icons-launcher.html#foreground.type=image&foreground.space.trim=1&foreground.space.pad=0.2&foreColor=rgba(96%2C%20125%2C%20139%2C%200)&backColor=rgb(197%2C%20202%2C%20233)&crop=0&backgroundShape=square&effects=shadow&name=ic_launcher

Trim
Padding 15%
Foreground transparent (to use SVG color #3F51B5)
Background color (#C5CAE9)
Scaling - Center
Shape - Square
Effect - Cast shadow

Generating Inkscape SVG with shadow:
 1. https://www.klaasnotfound.com/2016/09/12/creating-material-icons-with-long-shadows/ and https://graphicdesign.stackexchange.com/questions/77316/creating-icons-with-long-shadows-for-android
 2. Fix gradient non-stop issue by generating a "non-stop" version for import into Android Studio Image Asset adaptive icons - https://github.com/14v/svg-non-stop